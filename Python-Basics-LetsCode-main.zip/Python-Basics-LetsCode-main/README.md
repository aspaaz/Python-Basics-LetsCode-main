# Python-Basics-LetsCode
Exercicios propostos no curso Python Basics da Let's Code

[![Modulo 1](img/button_modulo-basics.png "Modulo - 1")](https://github.com/Rafael-T-Santos/Python-Basics-LetsCode/tree/main/Modulo%201%20-%20Basics)

[![Modulo 2](img/button_modulo-estruturas-avancadas.png "Modulo - 2")](https://github.com/Rafael-T-Santos/Python-Basics-LetsCode/tree/main/Modulo%202%20-%20Estruturas%20Avan%C3%A7adas)

[![Modulo 3](img/button_modulo-aplicacoes.png "Modulo - 3")](https://github.com/Rafael-T-Santos/Python-Basics-LetsCode/tree/main/Modulo%203%20-%20Aplica%C3%A7%C3%B5es)

OBS.: Ainda estou concluindo os exercicios.