# Exercicios - Modulo 1
## Clique na imagem para abrir o arquivo com soluções

[![Questão 1](img/Exercicio_01.png "Questão 1")](solucoes/Modulo_1.ipynb)

[![Questão 2](img/Exercicio_02.png "Questão 2")](solucoes/Modulo_1.ipynb)

[![Questão 3](img/Exercicio_03.png "Questão 3")](solucoes/Modulo_1.ipynb)

[![Questão 4](img/Exercicio_04.png "Questão 4")](solucoes/Modulo_1.ipynb)